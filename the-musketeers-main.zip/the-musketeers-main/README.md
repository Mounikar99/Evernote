# Group name 
The-Musketeers
# Principle 
We don't want to push our ideas on to customers, we simply want to make what they want. we Work with dedication as a self-organized team with customer satisfaction as our top priority and timely delivery of valuable product. 
WE HAVE ONLY ONE BOSS, THE "CUSTOMER"
# Project Idea
Our project name is Evernote2.0. It is a web based note taking app where a user will first get registered and then login to his account. User can also create new notes and could organize the notes and save them for later use.
Link : https://github.com/thegoldenmule/csci-5030/blob/main/notes/briefs/evernote.md
link : https://github.com/thegoldenmule/csci-5030/blob/main/notes/briefs/evernote-backlog.md
# Customer Dscription 
Our customer is the one who is looking for a web based application to save their notes and manage their task.
# Design Philosophy
Never assume a solution as the final Answer because nothing is final. Always try to work in interfaces as it is easy to modify smaller parts than whole program and clarity gives better understandig and better understanding means better modification.
# Trello 
Link : https://trello.com/b/OVU08fcJ/evernote20
